﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DBHelper
{
    public  class DBProcedures
    {
        SqlConnection connection;
        public DBProcedures(string data_source,bool integrated_security,string database_name,string username=null,string password=null)
        { 

            string connectionString = null;
            
            if (integrated_security == true)
            {
                connectionString = "Data Source=" + data_source + ";Integrated Security=true;" + "database=" + database_name;
            }
            else 
            {
                connectionString = "Data Source=" + data_source + ";Initial Catalog=" + database_name + ";User ID=" + username + ";password=" + password;
            }
            connection = new SqlConnection(connectionString);
            try
            {
                connection.Open();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }
        public string getAccountTypeName(int account_id)
        {
            string account_name=null;
            using (SqlCommand cmd = new SqlCommand("getAccountTypeName", connection))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@account_id", SqlDbType.Int).Value = account_id;
                cmd.Parameters.Add("@account_name", SqlDbType.VarChar, 255);
                cmd.Parameters["@account_name"].Direction = ParameterDirection.Output;

                try
                {
                    cmd.ExecuteNonQuery();
                    account_name = cmd.Parameters["@account_name"].Value.ToString();

                }
                catch(Exception ex)
                {
                    throw ex;
                }

            }
            return account_name;
        }

        public int validateCredentials(string email_address, string password)
        {
            int val;
            using (SqlCommand cmd = new SqlCommand("validateCrredentials", connection))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@email_address", SqlDbType.VarChar,255).Value = email_address;
                cmd.Parameters.Add("@password", SqlDbType.VarChar, 255).Value=password;
                

                try
                {
                    
                    val=(int)cmd.ExecuteScalar();
                    

                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }
            return val;
        }
    }
}
